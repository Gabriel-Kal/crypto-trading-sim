import axios from 'https://cdn.jsdelivr.net/npm/axios@1.3.5/+esm';

// The method we use to get the prices of the crypto coins requires the coin-currency pairs 
// example for bitcoin in the USA it would be BTCUSD 
// what we do is we fetch the "names" of the coins from a names.txt file where each coin name is stored
fetch("names.txt")
.then(r=>r.text())
.then(text => {
    const lines = text.split("\n").map(line => line.trim()).filter(line => line); // this constant is a list that contains every line (name) from the names.txt file
    const table = document.getElementById("table").getElementsByTagName("tbody")[0]; // here we get the table body of the table in the html file  

    // with these for loops we make the all the other rows of the tables 
    // (besides the header which is made in the html file) 
    for (let i = 0; i < lines.length; i++) {
      const row = table.insertRow(); // Create a new  row

      for (let j = 0; j < 3; j++) {
        const cell = row.insertCell(); // Create a cell in each column
        if(i>0, j==0){cell.textContent = i+1;} // if statement that sets the numbers in the first column (besides the header cell)
        if(i>0, j==1){cell.textContent = lines.at(i);} // if statement that sets the name in the second column (besides the header cell)
      }
    }
    
    // With this function we get the prices for each coin and we add the, in the third column of the table
    async function setData() {
      const table = document.getElementById("table");

      const requests = lines.slice(1).map(line =>
      axios.get(`https://api.kraken.com/0/public/Ticker?pair=${line}`)
      );

      try {
        const responses = await Promise.all(requests);

        responses.forEach((response, i) => {
          const tickerData = response.data.result[lines[i + 1]];
          const data = tickerData.c[0].slice(0, tickerData.c[0].length - 3);
          const row = table.getElementsByTagName("tr")[i + 1];
          const td = row.getElementsByTagName("td")[2];
          td.innerHTML = "$" + parseFloat(data);
        });
      } 
      catch (error) {
        console.error("Error fetching prices:", error);
      }
    }

  setData();
  
  // this fucntion is use to sort the data of our table 
  // we are sorting by price in descending order which is in the third column (or if we count from 0 it's column 2)
  function sortTable(table, column, asc = true ) {
  const dirModifier = asc ? 1 : -1;
  const tBody = table.tBodies[0];
  const rows = Array.from(tBody.querySelectorAll("tr"));

  const sortedRows = rows.sort((a,b)=>{
    const aColPrice = parseFloat(a.querySelector(`td:nth-child(${column + 1})`).textContent.trim().replace('$', ''));
    const bColprice = parseFloat(b.querySelector(`td:nth-child(${column + 1})`).textContent.trim().replace('$', ''));

    return aColPrice > bColprice ? (1 * dirModifier) : (-1 * dirModifier);
  });
  
  while (tBody.firstChild){
    tBody.removeChild(tBody.firstChild);

  }

  tBody.append(...sortedRows);
}
setTimeout(() => sortTable(document.querySelector("table"), 2, false), 5000); // since there is a delay before the prices are added we put a delay on calling the sort function

// Since we only need the top 20 coins sorted by price this function was made to remove all other orws of the table after the sorting is done
function deleteRows() {
  for(var i=lines.length; i>=22; i--){
    document.getElementById("table").deleteRow(i);
  }
  document.getElementById("table").deleteRow(1);
}
setTimeout(() => deleteRows(), 5500);
})





